<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/dist/tabler-icons.min.css">
<x-marketplace-layout title="Souk — Produits">

  <div class="app">
    @include('profile.vendeur.partials.sidebar', ['active' => 'produits'])

    <main class="main">
      <div class="top-row">
        <h1 class="page-title">Mes produits</h1>
        <div class="header-actions">
          <a href="{{ route('vendeur.boutique') }}" class="btn btn-primary"><i class="ti ti-plus"></i> Ajouter un produit</a>
        </div>
      </div>

      <div class="panel" style="padding: 0;">
        @forelse ($produits as $produit)
          @php $badge = $produit->statutBadge(); @endphp
          <div class="moderation-card" id="produit-{{ $produit->id }}">
            <div class="moderation-thumb" @if($produit->cover()) style="background-image:url('{{ $produit->cover()->url() }}');" @endif></div>
            <div class="moderation-info">
              <div class="nom">{{ $produit->nom }}</div>
              <div class="meta">{{ $produit->categorie ?? 'Sans catégorie' }} · {{ number_format($produit->prix, 2) }} DT · Stock : {{ $produit->stock }}</div>
              <span class="statut-pill {{ $badge['classe'] }}">{{ $badge['texte'] }}</span>
              @if ($produit->statut === 'refuse' && $produit->raison_refus)
                <div class="desc" style="color: var(--terracotta); margin-top: 8px;"><i class="ti ti-info-circle"></i> {{ $produit->raison_refus }}</div>
              @endif
            </div>
            <div class="moderation-actions">
              @if ($produit->statut === 'en_ligne')
                <a href="{{ route('produit-detail.index', $produit) }}" class="admin-btn admin-btn-outline">Voir</a>
              @endif
              <a href="{{ route('vendeur.produits.edit', $produit) }}" class="admin-btn admin-btn-outline">Modifier</a>
              <button type="button" class="admin-btn admin-btn-refuse" onclick="supprimerProduit({{ $produit->id }})">Supprimer</button>
            </div>
          </div>
        @empty
          <div class="empty-state">
            <i class="ti ti-package"></i>
            Tu n'as pas encore ajouté de produit.
            <div style="margin-top: 12px;">
              <a href="{{ route('vendeur.boutique') }}" class="btn btn-primary" style="display:inline-flex;"><i class="ti ti-plus"></i> Ajouter un produit</a>
            </div>
          </div>
        @endforelse
      </div>
    </main>
  </div>

  <script>
    function supprimerProduit(produitId) {
      if (! confirm('Supprimer ce produit ? Cette action est définitive.')) return;

      fetch(`/vendeur/produits/${produitId}`, {
        method: 'DELETE',
        headers: {
          'Accept': 'application/json',
          'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
        },
      })
        .then(async (r) => {
          const data = await r.json();
          if (! r.ok || ! data.success) {
            throw new Error(data.message || 'Erreur');
          }
          showToast(data.message, 'success');
          const el = document.getElementById(`produit-${produitId}`);
          if (el) el.remove();
        })
        .catch((err) => showToast(err.message || 'Erreur lors de la suppression.', 'error'));
    }
  </script>

</x-marketplace-layout >